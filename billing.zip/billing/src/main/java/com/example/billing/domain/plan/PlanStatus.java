package com.example.billing.domain.plan;

public enum PlanStatus {
    ACTIVE,
    INACTIVE,
    OBSOLETE
}
