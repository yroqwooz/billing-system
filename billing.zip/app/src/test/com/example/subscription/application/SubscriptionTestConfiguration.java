package com.example.subscription.application;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example.subscription")
public class SubscriptionTestConfiguration {
    // Пустой класс, нужен только для контекста теста
}
