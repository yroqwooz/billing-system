package com.example.subscription.application.exceptions;

public class PlanNotFoundException extends RuntimeException {}
