package com.example.subscription.web.dto;

import java.util.UUID;

public record CreateSubscriptionResponse(
        UUID subscriptionId
) {}
