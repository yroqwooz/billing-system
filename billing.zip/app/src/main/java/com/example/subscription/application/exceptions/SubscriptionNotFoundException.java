package com.example.subscription.application.exceptions;

public class SubscriptionNotFoundException extends RuntimeException {}
