package com.example.subscription.infrastructure.persistence.entity;

public enum SubscriptionStatusJpa {
    ACTIVE,
    CANCELLED
}