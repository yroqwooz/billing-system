package com.example.subscription.web.exception;

public record ErrorResponse(String message) {}
