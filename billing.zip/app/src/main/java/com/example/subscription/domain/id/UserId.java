package com.example.subscription.domain.id;

import java.util.UUID;

public record UserId(UUID value) {}