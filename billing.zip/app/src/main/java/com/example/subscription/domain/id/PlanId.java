package com.example.subscription.domain.id;

import java.util.UUID;

public record PlanId(UUID value) {}